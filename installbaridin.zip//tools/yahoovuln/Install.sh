# EmailVuln
BERFUNGSI UNTUK MENCARI EMAIL YAHOO YANG VULN ATAU UDAH MATI
KAMU BISA MEMAKAI UNTUK HACK FB DENGAN METODE CLONING EMAIL
PAKAILAH DENGAN BIJAK YA ;)
# Cara Pakai
Harap kamu mempunyai kuota internet
#### $ apt update && apt upgrade
#### $ apt install git
#### $ apt install python2
#### $ apt install figlet
#### $ git clone (link nya)
#### $ cd EmailVuln
#### $ python2 vuln.py
## HARAP MEMAKAI TOOL INI AKUN FB NYA HARUS KUAT
## KARENA BISA MENYEBABKAN CEKPOINT
# SEKIAN DARI SAYA
