#usr/bin/bash
clear
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
echo $bi "|" " 1" " Yahoo Cloner	"
echo $bi "|" " 2" " Weeman		"
echo $bi "|" " 3" " Kembali		"
echo
echo $ku "==="PILIH NOMOR"==="
echo "¦"
read -p"└──# " pil
if [ $pil = 1 ]
then
cd yahoovuln
python2 vuln.py
clear
fi

if [ $pil = 2 ]
then
cd weeman
python2 weeman.py
clear
fi

if [ $pil = 3 ]
then
cd $HOME/baridin
sh mainmenu.sh
clear
fi

