#usr/bin/bash
clear
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
echo LOADING
echo $pu "[===10%]"
sleep 1
echo $pu "[====20%]"
sleep 1
echo $pu "[=====30%]"
sleep 1
echo $pu "[======40%]"
sleep 1
echo $pu "[=======50%]"
sleep 1
echo $pu "[========60%]"
sleep 1
echo $pu "[=========70%]"
sleep 1
echo $pu "[==========80%]"
sleep 1
echo $pu "[===========90%]"
sleep 1
echo $pu "[============100%]"
sleep 1
echo
echo
echo $i "Loading Selesai. Tunggu Sebentar"
sleep 5
clear
echo $i " 1" "Masuk Tools"
echo $i " 2" "Keluar"
echo
echo "==="PILIH NOMOR"==="
echo "¦"
read -p"└──# " pil

if [ $pil = 1 ]
then
cd $HOME/baridin/tools
sh tools.sh
clear
fi

if [ $pil = 2 ]
then
clear
echo $cy"Bye Bye"
sleep 2
fi

if [ $pil = 0 ]
then
clear
cd $HOME/baridin
sh baridin.sh
fi

