clear
echo $i " 1" "Masuk Tools"
echo $me " 2" "Keluar"
echo
echo "==="PILIH NOMOR"==="
echo "¦"
read -p"└──# " pil

if [ $pil = 1 ]
then
cd tools
sh tools.sh
clear
fi

if [ $pil = 2 ]
then
clear
echo $cy"Bye Bye"
sleep 2
fi

if [ $pil = 0 ]
then
clear
cd $HOME
sh startbaridin.sh
fi
