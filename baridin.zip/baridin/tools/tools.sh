#usr/bin/bash
clear
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
echo "|" " 1" " Yahoo Cloner	"
echo "|" " 2" " Weeman		"
echo "|" " 3" " Exit            "
echo
echo "==="PILIH NOMOR"==="
echo "¦"
read -p"└──# " pil
if [ $pil = 1 ]
then
cd yahoovuln
python vuln.py
clear
fi

if [ $pil = 2 ]
then
cd weeman
python2 weeman.py
clear
fi

if [ $pil = 3 ]
then
echo $cy"Bye Bye"
sleep 2
fi

